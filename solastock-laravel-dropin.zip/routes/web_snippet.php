<?php

use Illuminate\Support\Facades\Route;

Route::view('/solastock', 'solastock')->name('solastock.demo');
