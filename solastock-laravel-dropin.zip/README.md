# SolaStock Laravel Drop-in

1. Copy `public/solastock` into your Laravel project's `public/solastock`.
2. Copy `resources/views/solastock.blade.php` into `resources/views/solastock.blade.php`.
3. Add the route from `routes/web_snippet.php` into your Laravel `routes/web.php`.
4. Visit `/solastock`.

This is a quick-start compatibility version. It keeps Claude Design's browser/Babel setup so it runs immediately inside Laravel. Later, convert to Vite React modules for production.
